import psycopg

def get_db_connection():
    return psycopg.connect(
        dbname="test",
        user="postgres",
        password="Natraj1345#",
        host="localhost",
        port="5432"
    )
