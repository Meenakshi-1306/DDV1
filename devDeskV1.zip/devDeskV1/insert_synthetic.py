import random
from db_config import get_db_connection
from datetime import datetime, timedelta

def insert_synthetic_data():
    conn = get_db_connection()  # Corrected function name
    cursor = conn.cursor()

    for _ in range(20):  # Insert 100 synthetic records
        cpu_percent = random.uniform(10, 90)
        ram_percent = random.uniform(30, 90)
        disk_read = random.randint(100, 500)
        disk_write = random.randint(100, 500)
        battery_percent = random.randint(50, 100)
        uptime = str(timedelta(seconds=random.randint(3600, 7200)))  # Random uptime between 1-2 hours
        timestamp = datetime.now() - timedelta(minutes=random.randint(1, 100))

        cursor.execute("""
            INSERT INTO system_data (cpu_percent, ram_percent, disk_read, disk_write, battery_percent, uptime, timestamp)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (cpu_percent, ram_percent, disk_read, disk_write, battery_percent, uptime, timestamp))

    conn.commit()
    cursor.close()
    conn.close()

# Run the function to insert synthetic data
insert_synthetic_data()
