import psutil
import platform
import datetime

def get_system_performance():
    uptime_seconds = (datetime.datetime.now() - datetime.datetime.fromtimestamp(psutil.boot_time())).total_seconds()

    try:
        battery = psutil.sensors_battery()
        battery_status = {
            "percent": battery.percent,
            "charging": battery.power_plugged
        } if battery else "Not available"
    except:
        battery_status = "Unavailable"

    return {
        "cpu_percent": psutil.cpu_percent(interval=1),
        "ram_percent": psutil.virtual_memory().percent,
        "disk_read": psutil.disk_io_counters().read_bytes,
        "disk_write": psutil.disk_io_counters().write_bytes,
        "battery": battery_status,
        "uptime": str(datetime.timedelta(seconds=int(uptime_seconds))),
        "running_processes": len(psutil.pids()),
        "temperature": get_temperature(),
        "platform": platform.system()
    }

def get_temperature():
    try:
        temps = psutil.sensors_temperatures()
        if not temps:
            return "Temperature data not available"
        # Return first temperature reading
        for name, entries in temps.items():
            for entry in entries:
                return f"{entry.current} °C"
    except:
        return "Unavailable"
