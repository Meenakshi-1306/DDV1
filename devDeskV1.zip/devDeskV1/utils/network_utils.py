import psutil
import socket
import speedtest
# network_utils.py

import socket

def is_connected():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=2)
        return True
    except OSError:
        return False


def is_connected():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=2)
        return True
    except OSError:
        return False

def get_network_metrics():
    stats = psutil.net_io_counters()
    return {
        "bytes_sent": stats.bytes_sent,
        "bytes_recv": stats.bytes_recv,
        "packets_sent": stats.packets_sent,
        "packets_recv": stats.packets_recv
    }

def get_speed():
    try:
        st = speedtest.Speedtest()
        st.get_best_server()
        return {
            "download": round(st.download() / 1_000_000, 2),  # Mbps
            "upload": round(st.upload() / 1_000_000, 2),      # Mbps
            "ping": st.results.ping
        }
    except Exception:
        return {"download": 0, "upload": 0, "ping": 0}
