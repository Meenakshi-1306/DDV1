from flask import Flask, request, jsonify, render_template
import datetime

# Import your custom utilities and routes
from utils.network_utils import is_connected, get_network_metrics, get_speed
from routes.system_status import status_bp
from routes.dashboard import dashboard_bp

app = Flask(__name__)

# Register blueprints
app.register_blueprint(status_bp)
app.register_blueprint(dashboard_bp)

# Sensor data store
sensor_data = {
    "temperature": None,
    "humidity": None,
    "air_quality": None,
    "rain": None,
    "timestamp": None
}

# Home route: Display latest sensor data
@app.route('/')
def index():
    return render_template("index.html", data=sensor_data)

# Route to receive sensor data
@app.route('/data', methods=['POST'])
def receive_data():
    global sensor_data
    data = request.get_json()
    if data:
        sensor_data.update({
            "temperature": data.get("temperature"),
            "humidity": data.get("humidity"),
            "air_quality": data.get("air_quality"),
            "rain": data.get("rain"),
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        return jsonify({"status": "success"}), 200
    return jsonify({"status": "error"}), 400


@app.route('/search')
def search():
    query = request.args.get("query")
    # Fake AI response for demo
    answer = f"This is a simulated response about '{query}'. Integrate OpenAI API for real output."
    return render_template("search.html", query=query, answer=answer)
# Run the app
if __name__ == '__main__':
    app.run(debug=True)
