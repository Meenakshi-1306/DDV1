from flask import Blueprint, jsonify
from utils.system_monitor import get_system_performance

status_bp = Blueprint('system_status', __name__)

@status_bp.route('/api/system-status', methods=['GET'])
def system_status():
    data = get_system_performance()
    return jsonify(data)
