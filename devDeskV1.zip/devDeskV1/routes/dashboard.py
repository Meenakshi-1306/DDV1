from flask import Blueprint, render_template
import psutil
from datetime import datetime
import time
import threading
from db_config import get_db_connection

dashboard_bp = Blueprint('dashboard', __name__)

# Function to get system metrics
def get_system_metrics():
    
    cpu_percent = psutil.cpu_percent(interval=1)
    ram_percent = psutil.virtual_memory().percent
    disk_read = psutil.disk_io_counters().read_bytes
    disk_write = psutil.disk_io_counters().write_bytes
    battery = psutil.sensors_battery()
    battery_percent = battery.percent if battery else 100  # Default to 100% if no battery info
    uptime = str(datetime.now() - datetime.fromtimestamp(psutil.boot_time()))

    return {
        'cpu_percent': cpu_percent,
        'ram_percent': ram_percent,
        'disk_read': disk_read,
        'disk_write': disk_write,
        'battery_percent': battery_percent,
        'uptime': uptime
    }

# Function to insert system data into the database
def insert_data_to_db(data):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(""" 
        INSERT INTO system_data (cpu_percent, ram_percent, disk_read, disk_write, battery_percent, uptime)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (data['cpu_percent'], data['ram_percent'], data['disk_read'], data['disk_write'], data['battery_percent'], data['uptime']))
    
    conn.commit()
    cursor.close()
    conn.close()

# Function to fetch the latest 12 entries from the database
def fetch_latest_data():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(""" 
        SELECT cpu_percent, ram_percent, disk_read, disk_write, battery_percent, uptime, timestamp
        FROM system_data
        ORDER BY timestamp DESC
        LIMIT 12
    """)
    
    data = cursor.fetchall()
    cursor.close()
    conn.close()
    return data

# Background thread to fetch data and store it periodically
def background_task():
    while True:
        data = get_system_metrics()
        insert_data_to_db(data)
        time.sleep(60)  # Collect data every 30 seconds (adjustable)

# Start the background task in a separate thread
threading.Thread(target=background_task, daemon=True).start()

# Route to serve the dashboard page
@dashboard_bp.route('/dashboard')
def dashboard():
    # Fetch the latest 12 entries from the database
    data = fetch_latest_data()

    # Structure the data for the frontend
    history_data = {
        "cpu_history": [entry[0] for entry in data],
        "ram_history": [entry[1] for entry in data],
        "disk_read_history": [entry[2] for entry in data],
        "disk_write_history": [entry[3] for entry in data],
        "battery_history": [entry[4] for entry in data],
        "uptime_history": [entry[5] for entry in data],
        "timestamps": [entry[6].strftime("%H:%M") for entry in data]
    }
    return render_template('dashboard.html', data=history_data)
from flask import jsonify

@dashboard_bp.route('/api/metrics')
def get_metrics():
    data = fetch_latest_data()
    history_data = {
        "cpu_history": [entry[0] for entry in data],
        "ram_history": [entry[1] for entry in data],
        "disk_read_history": [entry[2] for entry in data],
        "disk_write_history": [entry[3] for entry in data],
        "battery_history": [entry[4] for entry in data],
        "uptime_history": [entry[5] for entry in data],
        "timestamps": [entry[6].strftime("%H:%M") for entry in data]
    }
    
    